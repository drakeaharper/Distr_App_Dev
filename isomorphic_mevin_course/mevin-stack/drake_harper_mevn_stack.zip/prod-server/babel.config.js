"use strict";

module.exports = {
  presets: ['@vue/cli-plugin-babel/preset']
};